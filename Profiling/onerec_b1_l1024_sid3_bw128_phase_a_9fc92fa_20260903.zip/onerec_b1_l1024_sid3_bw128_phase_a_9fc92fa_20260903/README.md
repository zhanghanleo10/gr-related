# OneRec-1.7B Phase A B1/L1024/SID3/BW128 full trace

采集基于 `issue54-phase-a@9fc92fa5093bd0f6201ba1e443b2ee3d4eeac997`，
使用 NVIDIA L20 GPU 0 和本地 OneRec-1.7B BF16 真实权重。配置为 batch=1、
模型输入 1,024 tokens（提交 1,023，GR 追加一个 `<|sid_begin|>`）、3 个 SID、
beam width 128、AsyncScheduler、persistent request/state、Constraint Table、
CUSTOM attention 和 exact CUDA Graph。PrefixCaching 开启，但每次请求前清空，
因此采集的是真实 prefix miss。

## 延迟

3 次 warmup 后运行 5 次未插桩请求：

| 指标 | 时间 |
|---|---:|
| Mean | 87.519 ms |
| P50 | 83.395 ms |
| P90 | 93.816 ms |
| Min / Max | 83.288 / 93.971 ms |

开启 CPU+CUDA、Python stack、operator shape 和 memory 后，trace 中
`onerec_profiled_request` 区间为 168.301 ms。脚本测得的 690.688 ms 还包含
profiler context 收尾处理，只用于说明插桩开销，不能作为服务延迟。

## CPU/GPU 时间线

| Stage | CPU duration | CPU gap | GPU duration | GPU gap | GPU kernel |
|---|---:|---:|---:|---:|---:|
| Prefill, L=1024 | 69.667 ms | — | 59.228 ms | — | 30.916 ms |
| Decode-1, BW=128 | 10.215 ms | 5.981 ms | 16.544 ms | 7.296 ms | 8.671 ms |
| Decode-2, BW=128 | 9.860 ms | 8.453 ms | 16.257 ms | 2.123 ms | 8.687 ms |

Trace 中恰好有 2 次 `cudaGraphLaunch`，与 Worker 的 FULL graph dispatch 增量
2 一致。GPU stage gap 是 profiler 时间线观测值，受 stack/memory 插桩影响；
非插桩 P50 才是端到端性能基线。

## 完整性与状态

- 总事件 51,425；Python function 42,275，其中 `vllm_gr/` 1,572。
- CPU operator 2,110；CUDA kernel 1,762，累计 48.755 ms。
- Beam/constraint/KV decision kernel 12 次，累计 0.410 ms，占 kernel 时间 0.84%。
- Shape event 2,080；memory event 1,016。
- GPU memcpy 136 次、0.159 ms；其中 D2D 77 次、0.128 ms。
- 中间 Beam state D2H 为 0；最终 packed D2H 一次、5,120 bytes。
- 输出 128 beams，每条恰好 3 个 SID；best SID IDs 为
  `[159236, 167114, 171980]`。
- runner state 为 `created=9, freed=9, active=0`。
- 峰值 GPU allocated 21.285 GiB；Native KV 17.669 GiB；Beam KV 42 MiB；
  workspace 350.0 KiB；runner state 15.9 KiB。vLLM 启动日志报告 graph pool
  实际占用 0.27 GiB。

## 文件

- `onerec_b1_l1024_sid3_bw128_phase_a.pt.trace.json`：完整 CPU/GPU Chrome
  Trace，可用 Perfetto 打开；14,536,351 bytes；SHA-256
  `592838469011899a101b020320cf9276647c4c95f37dcadb9c3d95ea1f65b8f1`。
- `run.json`：采集契约、延迟、输出、graph、状态和显存数据。
- `analysis.json`：阶段时间线、range、kernel 和传输摘要。
- `profile_summary.json`：完整热点分析。
- `profiler_out.txt`：PyTorch profiler 原生 operator 表格。
- `profile_current.py`：复现脚本。

复现：

```bash
CUDA_VISIBLE_DEVICES=0 python \
  trace/onerec_b1_l1024_sid3_bw128_phase_a_9fc92fa_20260903/profile_current.py
```
