# OneRec-1.7B relational E2E profile (L20)

## Validated contract

- Date: 2026-08-28 UTC
- GPU: NVIDIA L20, GPU 0, no competing GPU allocation at either successful run start (14 MiB used)
- Model: `/home/z00469465/OneRec/OneRec-1.7B`, real local 3.97 GiB safetensors checkpoint, BF16
- Batch size: 1
- Beam width: 128
- SID steps: 3, followed by `<|sid_end|>`
- Input length: 1,024 model tokens = 1,023 submitted prompt tokens + one `<|sid_begin|>` appended by `GRLLM.beam_search`
- Output length: 1,028 tokens = input 1,024 + three SID tokens + `<|sid_end|>`
- Prefix caching: enabled, but reset before every independent request; every E2E sample contains a real 1K prefill
- CUDA backend: enabled (`device_config=cuda`, `enforce_eager=False`)
- Graph mode: vLLM `FULL_AND_PIECEWISE`; the OneRec BW128 device Beam FULL graph is replayed exactly twice per SID=3 request

## Unprofiled E2E latency

The performance number comes from a separate run without Kineto instrumentation. It includes the complete synchronous `beam_search` call and resets prefix cache outside the timed region.

| Sample | E2E latency (ms) |
|---:|---:|
| 1 | 112.797 |
| 2 | 113.155 |
| 3 | 110.725 |
| 4 | 115.849 |
| 5 | 121.835 |
| **Median** | **113.155** |
| Mean | 114.872 |
| Min / max | 110.725 / 121.835 |

The five requests produced 10 BW128 FULL graph replays, matching two decode replays per request.

## Relational trace

Open `run01/onerec_b1_input1024_sid3_bw128_rank0.1787932893393343336.pt.trace.json` directly in Perfetto or `chrome://tracing`. This is the native PyTorch/Kineto Chrome trace, not a simplified Nsight SQLite conversion.

Trace integrity:

- SHA-256: `78ab18141d6a8dd52b727c6ab0c83d5cd2508b2f38980e4731a6afd4dea3797e`
- Total events: 57,709
- `aten::` operator events: 2,191
- CUDA kernels: 1,849
- CPU-to-GPU flow events (`ac2g`): 3,193
- CUDA runtime events: 879
- GPU memcpy events: 152
- GPU memset events: 140
- Python call/stack events: 47,276

The main request hierarchy is visible as:

```text
execute_context_1(1024)_generation_0(0)     # real 1K prefill
  gpu_model_runner: preprocess
  gpu_model_runner: forward
    aten / compiled FX operators
      CUDA runtime launch --flow--> GPU kernel
  gpu_model_runner: postprocess
  gpu_model_runner: sample

execute_context_1(128)_generation_0(0)      # decode step 1, BW128 FULL graph
execute_context_1(128)_generation_0(0)      # decode step 2, BW128 FULL graph
```

Profiler-visible CPU scope durations were 70.377 ms for the prefill iteration and 12.404/10.216 ms for the two decode iterations. The profiled synchronous request took 193.573 ms because shape, stack, memory, CPU, and CUDA collection were all enabled. Do not use that instrumented wall time as the production E2E result; use the 113.155 ms unprofiled median above.

## How to inspect the relationships in Perfetto

1. Open the trace and search for `execute_context_1(1024)` to locate the prefill.
2. Expand the EngineCore CPU tracks and the GPU 0 stream tracks.
3. Expand `gpu_model_runner: forward`, `postprocess`, and `sample` to see their nested operators.
4. Select a CUDA runtime launch or an `aten::` slice. Perfetto highlights its connected `ac2g` flow and the destination kernel on the GPU stream.
5. Search for `execute_context_1(128)` to compare the two BW128 decode iterations.
6. Search `_local_beam_topk_kernel`, `_merge_beam_topk_kernel`, `_select_kv_gather_kernel`, `_select_kv_scatter_kernel`, and `_final_beam_outputs_kernel` to inspect the device-side Beam post-processing chain.

## Files

- `e2e_unprofiled_5runs.json`: authoritative unprofiled E2E samples and graph-dispatch validation
- `run01/run.json`: instrumented request contract, output validation, and profiled wall time
- `run01/onerec_b1_input1024_sid3_bw128_rank0.1787932893393343336.pt.trace.json`: native Chrome/Perfetto trace
- `run01/profiler_out_0.txt`: PyTorch profiler CUDA-time table

