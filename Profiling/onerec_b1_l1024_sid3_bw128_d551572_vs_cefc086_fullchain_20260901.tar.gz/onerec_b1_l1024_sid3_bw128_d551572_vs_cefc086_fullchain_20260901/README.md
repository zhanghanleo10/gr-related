# OneRec-1.7B B1/L1024/SID3/BW128 full-chain commit A/B profile

## Contract

- Before: `cefc086018cb7131d7a010ea70b1446521b915de`
- After: `d5515720c3cd0d0ddf21f913f05d0ccd8202da4f`
- OneRec-1.7B real BF16 weights, batch size 1, model input length 1024,
  beam width 128, three SID tokens.
- `constraint_table`, CUDA backend, CUSTOM attention, CUDA Graph enabled.
- Prefix cache is reset before every measured request (cache-miss trace).
- Both revisions were collected serially on the same physical NVIDIA L20 GPU 0.
- Three warmups and five unprofiled requests precede one profiled request.
- The profiled request records FrontEnd CPU and EngineCore/Worker CPU+CUDA
  separately, then merges them using the same-host monotonic timestamp.
- Engine trace enables Python stack, tensor shapes, memory events, CPU ATen,
  CUDA Runtime/Driver, kernels, memcpy, memset and NVTX annotations.

The best generated SID is `[159236, 167114, 171980]` in both revisions. Each
profiled request replays the BW128 FULL CUDA Graph exactly twice, matching the
two incremental decode model forwards.

## Dependency completeness

Inside EngineCore, CPU-to-GPU dependencies are explicit. Kernel and memcpy
events carry a CUDA `correlation` value (and memcpy also carries `External id`),
which maps to the exact `cuda*`/`cu*` API call on the EngineCore CPU thread.
The launch timestamp is nested back into ATen, NVTX and project Python frames.

FrontEnd and EngineCore are different processes. Kineto does not propagate a
correlation ID through the multiprocessing socket. Their events are therefore
merged by their common timestamp, while request-step edges are labelled
`inferred_by_ordered_blocking_request_step` in
`cross_process_dependencies.json`. No inferred IPC edge is represented as an
explicit CUDA dependency.

Open `before/merged_fullchain.pt.trace.json` and
`after/merged_fullchain.pt.trace.json` directly in Perfetto. The raw FrontEnd
and EngineCore traces remain alongside the merged files.

## Timing warning

Stack, shape, memory and two-process profiling materially inflate wall time.
Use the trace for structure and attribution, not as serving latency. The five
unprofiled requests immediately before profiling were:

| Revision | Mean | P50 | Min | Max |
|:--|--:|--:|--:|--:|
| before | 101.674 ms | 99.843 ms | 98.498 ms | 111.439 ms |
| after | 98.397 ms | 97.491 ms | 93.605 ms | 105.123 ms |

The larger cross-GPU performance matrix remains the source for stable latency
claims; these five samples only validate that this profiling run is not a cold
request.

## GPU model stages and inter-stage gaps

| Metric | Before | After | Delta |
|:--|--:|--:|--:|
| Prefill annotation | 61.782 ms | 64.121 ms | +2.338 ms |
| Prefill summed kernel time | 30.832 ms | 31.010 ms | +0.179 ms |
| Decode-1 annotation | 16.193 ms | 16.625 ms | +0.432 ms |
| Decode-1 summed kernel time | 8.700 ms | 8.686 ms | -0.014 ms |
| Decode-2 annotation | 16.299 ms | 16.382 ms | +0.083 ms |
| Decode-2 summed kernel time | 8.729 ms | 8.718 ms | -0.010 ms |
| Prefill context end -> Decode-1 context start | 23.267 ms | 26.931 ms | +3.663 ms |
| Decode-1 context end -> Decode-2 context start | 19.378 ms | 9.455 ms | **-9.923 ms** |

The model kernel sums are effectively unchanged, as expected. Annotation and
Prefill-gap differences are dominated by CPU profiler perturbation and the
FrontEnd round trip. The Decode-1-to-Decode-2 reduction is structurally backed
by the removal of the old decode postprocessing chain.

## Detailed GPU postprocessing timeline

All gaps below are measured on the GPU timestamp domain.

| Stage/interval | Before | After | Reduction |
|:--|--:|--:|--:|
| Prefill LM-head tail -> constrained TopK | 3.068 ms | 0.478 ms | 2.589 ms |
| Prefill TopK start -> result copy complete | 1.732 ms | 0.194 ms | 1.538 ms |
| Decode-1 LM-head tail -> constrained TopK | 2.580 ms | 0.011 ms | 2.569 ms |
| Decode-1 TopK end -> group start | 4.125 ms | 0.007 ms | 4.118 ms |
| Decode-1 TopK start -> result copy complete | 7.152 ms | 0.372 ms | 6.780 ms |
| Decode-2 LM-head tail -> constrained TopK | 2.730 ms | 0.016 ms | 2.715 ms |
| Decode-2 TopK end -> group start | 4.052 ms | 0.003 ms | 4.049 ms |
| Decode-2 TopK start -> result copy complete | 5.511 ms | 0.591 ms | 4.920 ms |

Kernel execution itself is not the old bottleneck:

| Kernel | Before | After |
|:--|--:|--:|
| Prefill `_fused_topk_kernel` | 184.577 us | 188.769 us |
| Decode-1 `_fused_topk_kernel` | 8.416 us | 8.672 us |
| Decode-2 `_fused_topk_kernel` | 7.935 us | 8.448 us |
| Decode-1 `_select_kv_scatter_kernel` | 18.048 us | 17.729 us |

The current prefill TopK is launched before the normal sampler boundary and
uses `PACK_PREFILL_RESULT`, so status/payload packing is folded into
`_fused_topk_kernel`; the trace correctly shows no separate prefill result
kernel. It is immediately followed by one 1540-byte pinned D2H
(`[status][token|score|parent]`).

The current incremental chain is:

```text
LM-head
-> _fused_topk_kernel
-> _beam_group_topk_kernel
-> _beam_group_finalize_kernel
-> (_select_kv_gather_kernel -> _select_kv_scatter_kernel, non-final step)
-> (_beam_result_pack_kernel, final step only)
-> one pinned result D2H
```

The old incremental chain contains the multi-launch local/merge/group/prefix/
write sequence, intermediate materialization and pageable result copy.

## CPU/API/allocation structural change

| Full profiled request | Before | After | Delta |
|:--|--:|--:|--:|
| GPU kernel events | 1810 | 1721 | -89 |
| CPU op events | 2233 | 1943 | -290 |
| Python function events | 46268 | 43849 | -2419 |
| Memory events | 1306 | 978 | -328 |
| `cudaLaunchKernel` | 294 | 217 | -77 |
| `cuLaunchKernelEx` | 27 | 15 | -12 |
| `cudaMemcpyAsync` | 157 | 116 | -41 |
| `cudaStreamSynchronize` | 49 | 28 | -21 |
| D2D copies | 72 | 56 | -16 |
| Pageable H2D | 40 | 25 | -15 |
| Pageable D2H | 6 | 3 | -3 |
| Pinned result D2H | 15 | 3 | -12 |

Profiler-inclusive `cudaStreamSynchronize` CPU time changes from 6.936 ms to
0.142 ms. This value is instrumentation-sensitive, but the call-count drop and
the disappearance of the old scalar/result synchronization pattern are real.

| Hot ATen op | Before calls | After calls |
|:--|--:|--:|
| `aten::all` | 3 | 0 |
| `aten::item` | 5 | 2 |
| `aten::_local_scalar_dense` | 5 | 2 |
| `aten::arange` | 8 | 0 |
| `aten::masked_fill*` | 6 | 0 |
| `aten::clone` | 7 | 0 |
| `aten::zeros_like` | 3 | 0 |
| `aten::cat` | 12 | 0 |
| `aten::bitwise_not` | 3 | 0 |
| `aten::empty` | 146 | 81 |
| `aten::empty_strided` | 128 | 88 |
| `aten::to` | 108 | 59 |
| `aten::copy_` | 163 | 129 |

## Cross-process request view

| Stage | FrontEnd blocking step before/after | GPU context end -> FrontEnd return before/after |
|:--|--:|--:|
| Prefill | 84.873 / 85.471 ms | 9.942 / 6.900 ms |
| Decode-1 | 49.039 / 31.590 ms | 25.958 / 7.540 ms |
| Decode-2 | 16.268 / 15.735 ms | 12.278 / 4.570 ms |

These are profiled blocking intervals. They show where FrontEnd is waiting and
where worker output becomes visible, but they must not be added to nested
EngineCore timings.

## Remaining optimization targets

1. **Prefill bootstrap / FrontEnd round trip remains the largest gap.** Current
   prefill result is GPU-ready in 0.194 ms after TopK, yet Decode-1 starts
   26.931 ms after prefill context end in this instrumented trace. Moving the
   1->W bootstrap/session seed into Worker/EngineCore remains the highest-value
   architectural optimization.
2. **Result-ready -> next decode still costs about 9.07 ms.** Current Decode-1
   result copy is complete roughly 9.072 ms before Decode-2 GPU execution.
   Profiled contributors include `_beam_self_advance`/request mutation,
   `_apply_beam_step`, scheduler processing and the next
   `patched_prepare_inputs`; further kernel fusion will not remove this gap.
3. **Constraint metadata preparation is still CPU-heavy.** Current profiled
   decode calls to `_populate_workspace_constraint_metadata` take about
   2.62/3.31 ms inclusive. They are now prelaunched so the GPU TopK follows the
   LM-head within 11-16 us, but resident device prefix/history and fixed-shape
   metadata would reduce CPU pressure and improve scheduling headroom.
4. **Final-step result tail is sub-millisecond.** Decode-2 TopK-to-result is
   0.591 ms, including grouped select, result pack, launch gaps and pinned D2H.
   It is a secondary target after removing the 9 ms orchestration gap.

## Artifacts

- `before/merged_fullchain.pt.trace.json`: before FrontEnd + EngineCore + GPU.
- `after/merged_fullchain.pt.trace.json`: after FrontEnd + EngineCore + GPU.
- `before/*rank0*.pt.trace.json`, `after/*rank0*.pt.trace.json`: raw EngineCore traces.
- `before/frontend.pt.trace.json`, `after/frontend.pt.trace.json`: raw FrontEnd traces.
- `cpu_gpu_ab_summary.json`: structured stage, operator, API and dependency data.
- `cpu_gpu_dependency_chain.csv`: focused CPU -> CUDA API -> key GPU activity rows.
- `cross_process_dependencies.json`: explicitly labelled inferred IPC/request edges.
- `fullchain_manifest.json`: byte sizes and SHA-256 checksums.
- `merge_fullchain.py`: reproducible trace merger.
