#!/usr/bin/env python3
"""Merge FrontEnd CPU and EngineCore CPU+CUDA Kineto traces by timestamp."""

from __future__ import annotations

import collections
import glob
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    manifest = {}
    cross_process = {}
    for label in ("before", "after"):
        directory = ROOT / label
        engine_path = Path(glob.glob(str(directory / "*rank0*.pt.trace.json"))[0])
        frontend_path = directory / "frontend.pt.trace.json"
        engine = json.loads(engine_path.read_text())
        frontend = json.loads(frontend_path.read_text())

        python_events = [
            event
            for event in frontend["traceEvents"]
            if event.get("cat") == "python_function"
        ]
        frontend_pid = collections.Counter(
            int(event["pid"]) for event in python_events
        ).most_common(1)[0][0]
        selected_frontend = [
            event
            for event in frontend["traceEvents"]
            if event.get("pid") == frontend_pid
        ]
        merged = dict(engine)
        merged["traceEvents"] = sorted(
            [*engine["traceEvents"], *selected_frontend],
            key=lambda event: float(event.get("ts", -1)),
        )
        merged["vllm_gr_fullchain"] = {
            "engine_trace": engine_path.name,
            "frontend_trace": frontend_path.name,
            "frontend_pid": frontend_pid,
            "note": (
                "Same-host monotonic timestamps are merged directly. CUDA correlation "
                "IDs are explicit inside EngineCore; cross-process request edges are "
                "inferred from ordered blocking request-step calls."
            ),
        }
        merged_path = directory / "merged_fullchain.pt.trace.json"
        merged_path.write_text(json.dumps(merged, separators=(",", ":")))

        contexts = sorted(
            [
                event
                for event in engine["traceEvents"]
                if event.get("cat") == "gpu_user_annotation"
                and str(event.get("name", "")).startswith("execute_context_1")
            ],
            key=lambda event: float(event["ts"]),
        )
        t0 = float(contexts[0]["ts"])
        steps = sorted(
            [
                event
                for event in selected_frontend
                if event.get("cat") == "python_function"
                and "vllm_gr/entrypoints/gr.py(248): _step_engine_and_collect_outputs"
                == event.get("name")
            ],
            key=lambda event: float(event["ts"]),
        )
        names = ("prefill", "decode_1", "decode_2")
        edges = []
        for index, (step, context) in enumerate(zip(steps, contexts, strict=True)):
            step_end = float(step["ts"]) + float(step["dur"])
            context_end = float(context["ts"]) + float(context["dur"])
            edges.append(
                {
                    "stage": names[index],
                    "frontend_wait_start_ms": round((float(step["ts"]) - t0) / 1000, 6),
                    "frontend_wait_duration_ms": round(float(step["dur"]) / 1000, 6),
                    "gpu_context_start_ms": round((float(context["ts"]) - t0) / 1000, 6),
                    "gpu_context_duration_ms": round(float(context["dur"]) / 1000, 6),
                    "gpu_context_end_to_frontend_return_ms": round(
                        (step_end - context_end) / 1000, 6
                    ),
                    "edge_type": "inferred_by_ordered_blocking_request_step",
                }
            )
        cross_process[label] = {
            "frontend_pid": frontend_pid,
            "engine_pid": contexts[0].get("args", {}).get("Process Id"),
            "request_step_edges": edges,
        }

        def file_info(path: Path):
            return {
                "path": str(path),
                "bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }

        manifest[label] = {
            "engine": file_info(engine_path),
            "frontend": file_info(frontend_path),
            "merged": file_info(merged_path),
        }

    (ROOT / "fullchain_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    )
    (ROOT / "cross_process_dependencies.json").write_text(
        json.dumps(cross_process, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({"manifest": manifest, "cross_process": cross_process}, indent=2))


if __name__ == "__main__":
    main()
