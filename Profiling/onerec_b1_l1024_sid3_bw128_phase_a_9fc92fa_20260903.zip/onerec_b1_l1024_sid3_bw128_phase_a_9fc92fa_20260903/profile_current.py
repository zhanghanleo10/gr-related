#!/usr/bin/env python3
"""Capture one full CPU+CUDA trace for the Phase-A persistent GR path."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import statistics
import subprocess
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch


HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[1]
MODEL = Path("/home/z00469465/OneRec/OneRec-1.7B")
CATALOG = Path("/home/z00469465/OneRec/generated_data/video_constraint_triples.json")
PROMPT = REPOSITORY / "tests/resources/single_one_rec_prompt.txt"
TRACE = HERE / "onerec_b1_l1024_sid3_bw128_phase_a.pt.trace.json"
INPUT_LEN = 1024
BEAM_WIDTH = 128
SID_STEPS = 3
WARMUPS = 3
BASELINE_RUNS = 5


def _prompt_tokens(tokenizer: Any) -> tuple[list[int], dict[str, Any]]:
    source = tokenizer.encode(PROMPT.read_text(encoding="utf-8"), add_special_tokens=False)
    target = INPUT_LEN - 1
    if len(source) >= target:
        tokens = source[-target:]
        adjustment = "left_truncate"
    else:
        newline = tokenizer.encode("\n", add_special_tokens=False)
        if len(newline) != 1:
            raise RuntimeError(f"newline must map to one token, got {newline}")
        tokens = [int(newline[0])] * (target - len(source)) + source
        adjustment = "left_pad_newline"
    if len(tokens) + 1 != INPUT_LEN:
        raise AssertionError("GR input length does not include exactly one appended begin token")
    return tokens, {
        "source_prompt_tokens": len(source),
        "submitted_prompt_tokens": len(tokens),
        "sid_begin_tokens_appended_by_grllm": 1,
        "model_input_tokens": len(tokens) + 1,
        "adjustment": adjustment,
    }


def _validate_output(output: Any, end_token_id: int) -> dict[str, Any]:
    if len(output) != 1:
        raise AssertionError(f"expected one request, got {len(output)}")
    sequences = output[0].sequences
    if len(sequences) != BEAM_WIDTH:
        raise AssertionError(f"expected {BEAM_WIDTH} beams, got {len(sequences)}")
    expected_length = INPUT_LEN + SID_STEPS + 1
    lengths = {len(sequence.tokens) for sequence in sequences}
    if lengths != {expected_length}:
        raise AssertionError(f"unexpected sequence lengths: {lengths}")
    if any(sequence.tokens[-1] != end_token_id for sequence in sequences):
        raise AssertionError("a sequence does not end with <|sid_end|>")
    sid_tokens = [list(sequence.tokens[INPUT_LEN:-1]) for sequence in sequences]
    if any(len(tokens) != SID_STEPS for tokens in sid_tokens):
        raise AssertionError("a sequence does not contain exactly three SID tokens")
    digest_rows = [
        {"tokens": sequence.tokens[-4:], "score": float(sequence.cum_logprob)}
        for sequence in sequences
    ]
    digest = hashlib.sha256(
        json.dumps(digest_rows, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return {
        "beam_count": len(sequences),
        "full_sequence_tokens": expected_length,
        "generated_sid_tokens_per_beam": SID_STEPS,
        "best_beam_sid_token_ids": sid_tokens[0],
        "result_sha256": digest,
    }


def _graph_stats(llm: Any) -> dict[str, Any]:
    replies = llm.llm_engine.engine_core.collective_rpc(
        "get_gr_beam_graph_runtime_stats"
    )
    if len(replies) != 1:
        raise RuntimeError(f"expected one Worker graph reply, got {replies}")
    return replies[0]


def _state_stats(llm: Any) -> dict[str, Any]:
    replies = llm.llm_engine.engine_core.collective_rpc(
        "get_gr_model_runner_state_stats"
    )
    if len(replies) != 1:
        raise RuntimeError(f"expected one Worker state reply, got {replies}")
    return replies[0]


def _latency_summary(samples: list[float]) -> dict[str, Any]:
    values = np.asarray(samples, dtype=np.float64)
    return {
        "samples_ms": [round(value, 6) for value in samples],
        "mean_ms": round(statistics.fmean(samples), 6),
        "min_ms": round(min(samples), 6),
        "p50_ms": round(float(np.percentile(values, 50)), 6),
        "p90_ms": round(float(np.percentile(values, 90)), 6),
        "max_ms": round(max(samples), 6),
    }


def _install_ranges(llm: Any) -> None:
    core = llm.llm_engine.engine_core.engine_core
    runner = core.model_executor.driver_worker.model_runner

    def wrap(obj: Any, name: str, label: str) -> None:
        original = getattr(obj, name)

        def traced(*args: Any, **kwargs: Any):
            with torch.autograd.profiler.record_function(label):
                return original(*args, **kwargs)

        setattr(obj, name, traced)

    wrap(core.scheduler, "schedule", "gr_schedule")
    wrap(runner, "_prepare_inputs", "gr_prepare_inputs")
    wrap(runner, "execute_model", "gr_execute_model")
    wrap(runner, "sample_tokens", "gr_sample_tokens")
    wrap(core.scheduler, "update_from_output", "gr_update_from_output")

    from vllm_gr.v1.worker.gr_model_runner_state import GRModelRunnerState

    original_final = GRModelRunnerState.make_final_output

    def traced_final(state: GRModelRunnerState):
        with torch.autograd.profiler.record_function("gr_final_result_d2h"):
            return original_final(state)

    GRModelRunnerState.make_final_output = traced_final


def main() -> None:
    for path in (MODEL, CATALOG, PROMPT):
        if not path.exists():
            raise FileNotFoundError(path)
    os.environ.setdefault("VLLM_ENABLE_V1_MULTIPROCESSING", "0")

    from vllm_gr.entrypoints.gr import GRLLM
    from vllm_gr.sampling_params import BeamSearchParams

    params = BeamSearchParams(
        beam_width=BEAM_WIDTH,
        max_tokens=5,
        temperature=0.0,
        ignore_eos=False,
        begin_token="<|sid_begin|>",
        end_token="<|sid_end|>",
    )
    engine_start = time.perf_counter()
    with GRLLM(
        model=str(MODEL),
        trust_remote_code=True,
        max_logprobs=BEAM_WIDTH,
        catalog_path=str(CATALOG),
        constraint_backend="constraint_table",
        beam_max_width=BEAM_WIDTH,
        beam_max_decode_steps=SID_STEPS,
        async_scheduling=True,
        persistent_request=True,
        persistent_runner_state=True,
        attention_config={"backend": "CUSTOM"},
        max_num_seqs=BEAM_WIDTH,
        enable_prefix_caching=True,
        gpu_memory_utilization=0.5,
        enforce_eager=False,
    ) as llm:
        engine_init_s = time.perf_counter() - engine_start
        tokenizer = llm.get_tokenizer()
        token_ids, prompt_metadata = _prompt_tokens(tokenizer)
        prompts = [{"prompt_token_ids": token_ids}]
        end_token_id = tokenizer.convert_tokens_to_ids("<|sid_end|>")
        initial_graph = _graph_stats(llm)
        if BEAM_WIDTH not in initial_graph["captured_widths"]:
            raise RuntimeError(f"BW{BEAM_WIDTH} FULL graph was not captured")

        warmup_ms = []
        output_metadata = None
        for _ in range(WARMUPS):
            if not llm.reset_prefix_cache():
                raise RuntimeError("prefix-cache reset failed")
            start = time.perf_counter()
            output = llm.beam_search(prompts, params)
            torch.cuda.synchronize()
            warmup_ms.append((time.perf_counter() - start) * 1000)
            output_metadata = _validate_output(output, end_token_id)

        baseline_ms = []
        for _ in range(BASELINE_RUNS):
            if not llm.reset_prefix_cache():
                raise RuntimeError("prefix-cache reset failed")
            start = time.perf_counter()
            output = llm.beam_search(prompts, params)
            torch.cuda.synchronize()
            baseline_ms.append((time.perf_counter() - start) * 1000)
            output_metadata = _validate_output(output, end_token_id)

        before_profile = _graph_stats(llm)
        _install_ranges(llm)
        if not llm.reset_prefix_cache():
            raise RuntimeError("prefix-cache reset failed")
        torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        with torch.profiler.profile(
            activities=(
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ),
            record_shapes=True,
            profile_memory=True,
            with_stack=True,
        ) as profiler:
            with torch.autograd.profiler.record_function("onerec_profiled_request"):
                output = llm.beam_search(prompts, params)
            torch.cuda.synchronize()
        profiled_ms = (time.perf_counter() - start) * 1000
        output_metadata = _validate_output(output, end_token_id)
        after_profile = _graph_stats(llm)
        state_stats = _state_stats(llm)
        memory_stats = llm.llm_engine.engine_core.collective_rpc(
            "get_gr_memory_stats"
        )[0]
        profiler.export_chrome_trace(str(TRACE))
        (HERE / "profiler_out.txt").write_text(
            profiler.key_averages(group_by_input_shape=True).table(
                sort_by="self_cuda_time_total", row_limit=200
            )
            + "\n",
            encoding="utf-8",
        )

        graph_delta = int(after_profile["full_dispatches"]) - int(
            before_profile["full_dispatches"]
        )
        if graph_delta != 2:
            raise RuntimeError(f"expected two BW128 graph replays, got {graph_delta}")
        if int(state_stats["active"]) != 0:
            raise RuntimeError(f"runner state leaked after profile: {state_stats}")
        result = {
            "contract": {
                "batch_size": 1,
                "model_input_tokens": INPUT_LEN,
                "sid_steps": SID_STEPS,
                "beam_width": BEAM_WIDTH,
                "dtype": "bfloat16",
                "mode": "exact_cuda_graph",
                "constraint_backend": "constraint_table",
                "attention_backend": "CUSTOM",
                "async_scheduling": True,
                "persistent_request": True,
                "persistent_runner_state": True,
                "prefix_caching": True,
                "prefix_cache_reset_before_each_request": True,
                "profile_activities": ["CPU", "CUDA"],
                "with_stack": True,
                "record_shapes": True,
                "profile_memory": True,
            },
            "revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=REPOSITORY, text=True
            ).strip(),
            "source_state": {
                "tracked_worktree_clean": not bool(
                    subprocess.check_output(
                        ["git", "status", "--short", "--untracked-files=no"],
                        cwd=REPOSITORY,
                        text=True,
                    ).strip()
                )
            },
            "paths": {
                "model": str(MODEL),
                "catalog": str(CATALOG),
                "prompt": str(PROMPT),
                "trace": str(TRACE),
            },
            "prompt": prompt_metadata,
            "output": output_metadata,
            "timing": {
                "engine_init_s": round(engine_init_s, 6),
                "warmup": _latency_summary(warmup_ms),
                "unprofiled_baseline": _latency_summary(baseline_ms),
                "profiled_request_ms": round(profiled_ms, 6),
            },
            "beam_graph": {
                "before_profile": before_profile,
                "after_profile": after_profile,
                "profile_full_dispatch_delta": graph_delta,
            },
            "runner_state": state_stats,
            "memory": memory_stats,
            "peak_gpu_bytes": torch.cuda.max_memory_allocated(),
            "environment": {
                "python": platform.python_version(),
                "torch": torch.__version__,
                "cuda_visible_devices": os.getenv("CUDA_VISIBLE_DEVICES"),
            },
        }

    result["trace_file"] = {
        "bytes": TRACE.stat().st_size,
        "sha256": hashlib.sha256(TRACE.read_bytes()).hexdigest(),
    }
    (HERE / "run.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print("ONEREC_PHASE_A_FULL_TRACE_RESULT")
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
